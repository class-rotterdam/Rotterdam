gOptions = {
    // REST API URL: example: http://ec2-54-93-55-4.eu-central-1.compute.amazonaws.com:8082
    api_url: 'http://192.168.7.24:8082',
    // APP VERSION
    version: '0.0.5',
    // REST API APP
    endpoint_restapi_root: 'http://192.168.7.24:8082/api/', // PUBLIC URL
    endpoint_restapi_version: 'http://192.168.7.24:8082/api/version', // LOCAL if brooklyn is in the same machine
    endpoint_restapi: 'http://192.168.7.24:8082', // PUBLIC URL
}
