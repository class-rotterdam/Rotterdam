angular.module('angular-app')

.controller('jsonK8Controller', function($rootScope, $scope, $log, $http) {
  /*****************************************************************
   * PROPERTIES, FLAGS, CONSTANTS
   *****************************************************************/

   // FUNCTION: testRESTAPI
   // GET /api
   $scope.testRESTAPI = function() {
     $scope.restestsk8 = "";

     $http.get($rootScope.restapi.url + "/api").success(function(data) {
         $log.debug(data);
         $log.debug("GET " + $rootScope.restapi.url + "/api");
         $scope.restestsk8 = JSON.stringify(data);
     })
     .error(function(err) {
         $log.error('Error: ' + err);
         $scope.restestsk8 = err;
     })
     .finally(function() {

     });
   }


   // FUNCTION: getTask
   // GET /api/v1/docks/:dock/tasks/:name
   $scope.getTask = function() {
     $scope.resgettask = "";

     $http.get($rootScope.restapi.url + "/api/v1/docks/" + $scope.gettaskdock + "/tasks/" + $scope.gettaskname).success(function(data) {
         $log.debug(data);
         $log.debug("GET " + $rootScope.restapi.url + "/api/v1/docks/" + $scope.gettaskdock + "/tasks/" + $scope.gettaskname);
         $scope.resgettask = JSON.stringify(data);
     })
     .error(function(err) {
         $log.error('Error: ' + err);
         $scope.resgettask = err;
     })
     .finally(function() {

     });
   }


   // FUNCTION: testRESTAPI2
   $scope.testRESTAPI2 = function() {
     $scope.restestsk8 = "";

     $http.get($rootScope.restapi.url).success(function(data) {
         $log.debug(data);
         $log.debug("GET " + $rootScope.restapi.url);
         $scope.restestsk8 = JSON.stringify(data);
     })
     .error(function(err) {
         $log.error('Error: ' + err);
         $scope.restestsk8 = err;
     })
     .finally(function() {

     });
   }


   // FUNCTION: getTaskContainers
   // GET /api/v1/docks/:dock/tasks/:name/containers
   $scope.getTaskContainers = function() {
     $scope.resgetpodstask = "";

     $http.get($rootScope.restapi.url + "/api/v1/docks/" + $scope.getpodstaskdock + "/tasks/" + $scope.getpodstaskname + "/containers").success(function(data) {
         $log.debug(data);
         $log.debug("GET " + $rootScope.restapi.url + "/api/v1/docks/" + $scope.getpodstaskdock + "/tasks/" + $scope.getpodstaskname + "/containers");
         $scope.resgetpodstask = JSON.stringify(data);
     })
     .error(function(err) {
         $log.error('Error: ' + err);
         $scope.resgetpodstask = err;
     })
     .finally(function() {

     });
   }


   // FUNCTION: sendNewTaskJSON
   // POST /api/v1/docks/:dock/tasks
   $scope.sendNewTaskJSON = function() {
     $scope.resk8 = "";

     var dataObj = {
       //json: $scope.jsonk8
       //$scope.jsonk8
     };

     $http.post($rootScope.restapi.url + "/api/v1/docks/" + $scope.newtaskdock + "/tasks", $scope.jsonk8).success(function(data) {
       $log.debug(data);
       $log.debug("POST " + $rootScope.restapi.url + "/api/v1/docks/" + $scope.newtaskdock + "/tasks");
       $scope.resk8 = JSON.stringify(data);
     })
     .error(function(err) {
       $log.error('Error: ' + err);
       $scope.resk8 = err;
     })
     .finally(function() {

     });
   }


   // FUNCTION: stopTask
   // DELETE /api/v1/docks/:dock/tasks/:name
   $scope.stopTask = function() {
     $scope.resstoptask = "";

     $http.delete($rootScope.restapi.url + "/api/v1/docks/" + $scope.stoptaskdock + "/tasks/" + $scope.stoptaskname).success(function(data) {
         $log.debug(data);
         $log.debug("DELETE " + $rootScope.restapi.url + "/api/v1/docks/" + $scope.stoptaskdock + "/tasks/" + $scope.stoptaskname);
         $scope.resstoptask = JSON.stringify(data);
     })
     .error(function(err) {
         $log.error('Error: ' + err);
         $scope.resstoptask = err;
     })
     .finally(function() {

     });
   }


   // FUNCTION: updateTaskJSON
   // PUT /api/v1/docks/:dock/tasks/:name
   $scope.updateTaskJSON = function() {
     $scope.updresk8 = "";

     var dataObj = {
       //json: $scope.updjsonk8
       //$scope.updjsonk8
     };

     $http.post($rootScope.restapi.url + "/api/v1/docks/" + $scope.updtaskdock + "/tasks/"  + $scope.updtaskname, $scope.updjsonk8).success(function(data) {
       $log.debug(data);
       $log.debug("POST " + $rootScope.restapi.url + "/api/v1/docks/" + $scope.updtaskdock + "/tasks/"  + $scope.updtaskname);
       $scope.updresk8 = JSON.stringify(data);
     })
     .error(function(err) {
       $log.error('Error: ' + err);
       $scope.updresk8 = err;
     })
     .finally(function() {

     });
   }


   // FUNCTION: getTaskDB
   // GET /api/v1/docks/tasks
   $scope.getTaskDB = function() {
     $scope.resgetdbtasks = "";

     $http.get($rootScope.restapi.url + "/api/v1/docks/tasks").success(function(data) {
         $log.debug(data);
         $log.debug("GET " + $rootScope.restapi.url + "/api/v1/docks/tasks");
         $scope.resgetdbtasks = JSON.stringify(data);
     })
     .error(function(err) {
         $log.error('Error: ' + err);
         $scope.resgetdbtasks = err;
     })
     .finally(function() {

     });
   }


   // FUNCTION: doNothing
   $scope.doNothing = function() {

   }





   $log.debug("jsonK8Controller initialized!");

});
