angular.module('angular-app')

.controller('homeController', function($rootScope, $scope, $log, $http) {
  /*****************************************************************
   * PROPERTIES, FLAGS, CONSTANTS
   *****************************************************************/

   // FUNCTION: updateRESTAPI
   $scope.updateRESTAPI = function() {
     $rootScope.restapi.url=$scope.restapi.url;
   }


   $log.debug("homeController initialized!");

});
