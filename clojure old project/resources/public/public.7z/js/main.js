angular.module('angular-app', ['ngStorage', 'ui.bootstrap'])


.controller('mainController', function($rootScope, $scope, $log, $http, $localStorage, $location, showAlertSrvc) {
  ///////////////////////////////////////////////////////////////////////////
  // BASE / REST API URL
	var str = $location.absUrl();
	var n = str.indexOf("#");
	if (n == -1) {
		$rootScope.approot = $location.absUrl().replace("index.html", "");
	}
	else {
		var res = str.substring(0, n);
		$rootScope.approot = res;
	}
  $rootScope.approot = $rootScope.approot.substring(0, $rootScope.approot.length - 1);

	$log.debug('>> app url: ' + $rootScope.approot);

  ///////////////////////////////////////////////////////////////////////////
  // $rootScope
  // content
  $rootScope.restapi= {
      url : gOptions.api_url
  };

  $rootScope.endpoint_restapi_root = gOptions.endpoint_restapi_root;
  $rootScope.endpoint_restapi = gOptions.endpoint_restapi;

  ///////////////////////////////////////////////////////////////////////////
  // 1st time page loading / reload ...
  $scope.app_version = gOptions.version;
  $scope.connected = false;

  $scope.rest_api_version = '-';
  $scope.endpoint = $rootScope.endpoint_restapi + '/api';
  $http.get($rootScope.endpoint_restapi + '/version').success(function(data) {
    if (data != null) {
        $scope.rest_api_version = data.version;
        $scope.connected = true;
    }
  })
  .error(function(data) {
      $log.error("" + data);
  })
  .finally(function() {
  });

  // content
  $scope.content= {
      active: false,
      url : 'home.html',
      current : 'Home'
  };
  $rootScope.currentPage = 'Home';
  $log.debug('>> app currentPage: ' + $rootScope.currentPage);

  ///// $localStorage
  $log.debug('>> Initialize $localStorage to store $scope content ... ');
  // content
  $localStorage.content = $scope.content;


  ///////////////////////////////////////////////////////////////////////////
  // FUNCTIONS / LINKS
  ///////////////////////////////////////////////////////////////////////////

  // FUNCTION: MENU: home
  $scope.home = function () {
      $scope.content.url = 'home.html';
      $scope.content.current = 'Home';
      $rootScope.currentPage = 'Home';
  }

  // FUNCTION: GET REQUEST
  $rootScope.doGet = function(endpoint) {
      $log.debug('doGet... ' + endpoint);
      $http.get(endpoint).success(function(data) {
          $log.debug(data);
      })
      .error(function(err) {
          $log.error(err);
      });
  }

})


.directive('ngConfirmBoxClick', [
    function () {
        return {
            link: function (scope, element, attr) {
                var msg = attr.ngConfirmBoxClick || "Are you sure want to delete?";
                var clickAction = attr.confirmedClick;
                element.bind('click', function (event) {
                    if (window.confirm(msg)) {
                        scope.$eval(clickAction)
                    }
                });
            }
        };
    }
])


.service('showAlertSrvc', ['$timeout', function($timeout) {
    return function(delay) {
        var result = {hidden:true};
        $timeout(function() {
            result.hidden=false;
        }, delay);
        return result;
    };
}]);
